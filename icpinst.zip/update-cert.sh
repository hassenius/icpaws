#!/bin/bash


crt_content='-----BEGIN CERTIFICATE-----
MIID+TCCAuGgAwIBAgIJAMJAXm576BhqMA0GCSqGSIb3DQEBCwUAMFoxCzAJBgNV
BAYTAkFVMRMwEQYDVQQIEwpTb21lLVN0YXRlMSEwHwYDVQQKExhJbnRlcm5ldCBX
aWRnaXRzIFB0eSBMdGQxEzARBgNVBAMTCm1hc3Rlci5jZmMwIBcNMTcwODIxMDc0
MzI0WhgPMjExNzA3MjgwNzQzMjRaMFoxCzAJBgNVBAYTAkFVMRMwEQYDVQQIEwpT
b21lLVN0YXRlMSEwHwYDVQQKExhJbnRlcm5ldCBXaWRnaXRzIFB0eSBMdGQxEzAR
BgNVBAMTCm1hc3Rlci5jZmMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
AQDmKcI02gTWX+ix8jkpek/wK0MgT8ZnUXIUOLyLftd5p4MvlQXrizmOqep75iFR
yJ/g5BYgmL4eV5maAxRCt3IyiR356HoBw8o4hkCE4xX1vTVpscIhROLu58R6CxjA
zFv9uV58Qg/3UVjZz1FMrKT6C2QOQEFIz2psVv88Ms1X1mvtzym7qH343jUoBiA4
PyIPCpl0wxkKw+g96m65CllW9pCeaLNwOBKe1MvIvQa1knN1zwnVh4haGZO5Mydg
nf8oJKKGaFhxweaychodOF82zb9YPAr676ecGJcd0Weni8LTjlAZFCoRPFj0ntUv
llpxfmgi2Vco0nOs2sAh+kQRAgMBAAGjgb8wgbwwHQYDVR0OBBYEFNauBMBy2rua
uEiU/X9QbYjTVYDtMIGMBgNVHSMEgYQwgYGAFNauBMBy2ruauEiU/X9QbYjTVYDt
oV6kXDBaMQswCQYDVQQGEwJBVTETMBEGA1UECBMKU29tZS1TdGF0ZTEhMB8GA1UE
ChMYSW50ZXJuZXQgV2lkZ2l0cyBQdHkgTHRkMRMwEQYDVQQDEwptYXN0ZXIuY2Zj
ggkAwkBebnvoGGowDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAQEAxK1e
8TPDBcUoaVzd1t/oV0VHrXGhRVO3g0IyhMZKf4rXhbCnWotBuzXCNWdqKs0Yjb2l
ywYLFBLT7rlrjQ0uROw5JkuuicHfYGNbQfKxuqaAX3K0YGmzqgfsvcjyJY+I9pvz
mZm5fQRYL4ucPEKLVYoYs1XxSCzFQweGd8f37a8GhxNF+K+/aTjKvdQeJuYG1f8d
PZTySJFH6arrsZT9Pcqx1q7SYOfmy+UyX87fywaHiIZUreJ6Vzalk3PImjdzE7fo
WtW5qe0VwJeLdIrgUYIs3N7ZEfvnQTbyLzezgzvtWKz7REVA321hu2RYo2eDSKx/
5/WiVITzw8ZDRWwRMg==
-----END CERTIFICATE-----'

key_content='-----BEGIN RSA PRIVATE KEY-----
MIIEpQIBAAKCAQEA5inCNNoE1l/osfI5KXpP8CtDIE/GZ1FyFDi8i37XeaeDL5UF
64s5jqnqe+YhUcif4OQWIJi+HleZmgMUQrdyMokd+eh6AcPKOIZAhOMV9b01abHC
IUTi7ufEegsYwMxb/blefEIP91FY2c9RTKyk+gtkDkBBSM9qbFb/PDLNV9Zr7c8p
u6h9+N41KAYgOD8iDwqZdMMZCsPoPepuuQpZVvaQnmizcDgSntTLyL0GtZJzdc8J
1YeIWhmTuTMnYJ3/KCSihmhYccHmsnIaHThfNs2/WDwK+u+nnBiXHdFnp4vC045Q
GRQqETxY9J7VL5ZacX5oItlXKNJzrNrAIfpEEQIDAQABAoIBAQDgBxlfNC6tMyFd
wzVcaA9S5+kolD275wyxHiB3bvjxEtmgAN+ISzW05TK1cmRQJIVp8tiO1d2HzyBV
RlX8Mm7XPZuN2niXKym0Jwi50AdZ79cDj+AzXce9Xp5hZFetobyQlFOhgvPjeKyR
JTgu94SFVX0IWgaxhiJCXdOFlrVEnjo4A9oc5EDxgFvNKF4/vWdA6EDL5fquhqOd
XHVgFwyeuqctdOuf6TYinHkKfjETTMBF5MNos1a1qObmZKGmKxnQYNTsMv6d5qN3
OYYMC9kymaEAJwJxUcBVxisFobthf62cRrTLNTRI+zf7UySdQeTbzWvXmLvV7C5e
YrUXa8ZZAoGBAPhyLgDM/12GXwZh5W646SWbgaeXnPiQzaIkvO7jPhC5tpWiwSre
WjvvxzPiH0eC0XSTV+wZMkKRW8Zf9H3srkssgz0j16c0YptQso+zRSXz/9X1NGa0
9v3bPtnwX5KQzMRO3brcrnrFPULWIYfgoqqLWHJJCgdJ2/oRV0ETh+Y7AoGBAO0p
RWDTHu4RIdK614099Gn8SBfaFnkiH9+uqv8Gu5wvc9rgkrufOiAPsBBZI5iFeVij
+/BTJynlip2u2wXXQE/GtdFeAa8PnfmDhOENR0dMFmYsVJBPfWNS+dtwBzLMppTo
cJe7gqNFzVXWh2IgiqVeo3Yp7Sf8RmBEHE3GMr4jAoGAAMAnj20PIHM1ekl1bf41
Bh4QKDd3C/E0DddaksYw+8/z00PonX6Kez/gNDHsskSc6WNAksAIvNa/ljvX+0Fp
zWRXCSpAjorD+YAm6fQ6s0CndzgEboMBdAbji7kEMOcrFzS9ysC77jcGVltbQpPV
Kfq9y6qY0yjP91NyFgo/EN0CgYEAw0VNC5kpiWlvyPvwiSou+akwjvsRr/Fp/xnp
T4xyovnrUZfBGVzUVhu0ovFSPr3/mP2Ebm94+qU2Sfjz+84s9MKvZ9EYX9TjBNPG
cCsnukuq0bvEcQISQtrKQWTveGNK8aalNjm9KcRKelfmJuSWY+0VeDCzRU4RgCf0
ihEcLLMCgYEA36Z9Al3UrDE7BtWkLN7Q39WJ+cbQLVJhGlsjRPI5VOXvVdul4S7i
B5rgNmQQyqnNEzjdSKJSBYgBloTRLBjqtDiKX9Mw3+xQ8tQ7a+1Uhz18yX2gXzxT
S9HtWGah8phY8ezVuEmop8Y9QhBoEUwtRcDfkvW5JoqhvUBiZwNSEbc=
-----END RSA PRIVATE KEY-----'

# Update Docker certificates
mkdir -p "/etc/docker/certs.d/master.cfc:8500"
echo "$crt_content" > "/etc/docker/certs.d/master.cfc:8500/ca.crt"

echo "docker registry certificate updated"

# Update key & crt files
if [[ -f /etc/cfc/conf/oidc-key.pem ]]; then
    echo "$crt_content" > /etc/cfc/conf/oidc.crt
    echo "$key_content" > /etc/cfc/conf/oidc-key.pem

    if [[ "$(uname -m)" == "x86_64" ]]; then
        docker pull ibmcom/cfc-router:1.2.0
    else
        docker pull ppc64le/cfc-router:1.2.0
    fi

    docker rm -f $(docker ps -q -f name=k8s_router_k8s-router)
    docker rm -f $(docker ps -q -f name=k8s_image-manager)
    docker rm -f $(docker ps -q -f name=k8s_cfc-registry)
    docker rm -f $(docker ps -q -f name=k8s_apiserver)
fi

echo "cfc-router certificate updated and restarted"
echo "update successful!"
