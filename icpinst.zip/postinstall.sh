#!/bin/bash
if [ $# -ne 1 ]; then
  echo "Usage: $0 <nodeuser loginid>"
  exit 1
fi

LOGFILE=/tmp/postinstall.log
exec > $LOGFILE 2>&1

echo "Running Update script..."
cd /tmp/icpinstall
chmod 755 update-cert.sh
sudo ./update-cert.sh
sudo systemctl stop docker
mywc=`netstat -an|grep -i time_wait|wc -l`
if [ $mywc -ne 0 ]; then
  sleep 5
  mywc=`netstat -an|grep -i time_wait|wc -l`
fi
sudo systemctl start docker

echo "updating nodes.."
declare -a ipaddress
IFS=', ' read -r -a ipaddress <<< `cat /tmp/test.txt`
for (( i=0; i < ${alen}-1; i++ ));
do
  ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i  /tmp/icpsshkey $nodeuser@${ipaddress[$i]} "cd /tmp/icpinstall; chmod 755 update-cert.sh; sudo ./update-cert.sh; sudo systemctl stop docker; sleep 120; sudo systemctl start docker"
done
