#!/bin/bash
#prepare hosts file to be copied to all the nodes
if [ $# -ne 3 ]; then
  echo "Usage: $0 <icpuser> <icppassword> <nodelogin user>"
  exit 1
fi

icpuser=$1
icppassword=$2
nodeuser=$3

LOGFILE=/tmp/masterinstall.log
exec  > $LOGFILE 2>&1

declare -a ipaddress 
IFS=', ' read -r -a ipaddress <<< `cat /tmp/test.txt`
declare -a myhostnames
IFS=', ' read -r -a myhostnames <<< `cat /tmp/test1.txt`

#add master ip to ipaddress array
masterip=`cat /tmp/masterip.txt`
ipaddress=("${ipaddress[@]}" "${masterip}")
mastername=`hostname` 
myhostnames=("${myhostnames[@]}" "${mastername}")
domain=`hostname -d`

#initialize hosts
echo "127.0.0.1   localhost localhost.localdomain" >/tmp/hosts

#prepare hosts file
alen=${#ipaddress[@]}
for (( i=0; i < ${alen}; i++ ));
do
  # check hostname resolution
  myname=`nslookup ${ipaddress[$i]}|grep name|cut -d= -f2|tr -d ' \t\n\r\f'`
  if  [ $? ]; then
    shortname=`echo $myname|cut -f1 -d.`
    echo ${ipaddress[$i]} ${myname: : -1} $shortname >> /tmp/hosts 
  else 
    shortname=`{myhostnames[$i]}|cut -f1 -d.`
    echo ${ipaddress[$i]} ${myhostnames[$i]}  ${shortname} >> /tmp/hosts
  fi
done

#prepare ICp hosts file
echo "[master]" > /tmp/icphosts
echo ${ipaddress[${alen}-1]} >> /tmp/icphosts
echo "" >> /tmp/icphosts
echo "[proxy]" >> /tmp/icphosts
echo  ${ipaddress[${alen}-2]} >> /tmp/icphosts 
echo "" >> /tmp/icphosts
echo "[worker]" >> /tmp/icphosts
for (( i=0; i < ${alen}-2; i++ ));
do
  echo  ${ipaddress[$i]}  >> /tmp/icphosts
done

#chmod for private key
chmod 0600 /tmp/icpsshkey

#Install prereqs on all nodes
for (( i=0; i < ${alen}-1; i++ ));
do
 echo ${ipaddress[$i]}
 nodename=`cat /tmp/hosts|grep  ${ipaddress[$i]}|cut -f2 -d" "`
 echo $nodename
 scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i /tmp/icpsshkey /tmp/icpinst.zip  $nodeuser@${ipaddress[$i]}:/tmp
 scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i /tmp/icpsshkey /tmp/hosts  $nodeuser@${ipaddress[$i]}:/tmp
 echo "Installing prereqs on node $ipaddress $nodename ..."
 ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i  /tmp/icpsshkey $nodeuser@${ipaddress[$i]} "cd /tmp; sudo apt-get install -y unzip; mkdir icpinstall; cd icpinstall; unzip -q ../icpinst.zip; chmod 755 *; ./prereqs.sh $nodename; sudo mv /etc/hosts /etc/hosts.orig; sudo cp /tmp/hosts /etc/" 
 #ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i  /tmp/icpsshkey ${ipaddress[$i]} "cd /tmp; mkdir icpinstall; cd icpinstall; unzip -q ../icpinst.zip; chmod 755 *; ./disk-part.sh; ./prereqs.sh $nodename; mv /etc/hosts /etc/hosts.orig; cp /tmp/hosts /etc/" 
done

#Increase FS with added disk on master
#/tmp/icpinstall/disk-part.sh

#Update /etc/hosts
sudo mv /etc/hosts /etc/hosts.orig
sudo cp /tmp/hosts /etc

#Run prereqs on master
masterhname=`cat /tmp/hosts|grep  ${ipaddress[$alen-1]}|cut -f2 -d" "`
echo $masterhname
/tmp/icpinstall/prereqs.sh $masterhname

#Expand ICp installer
echo "Preparing to install ICp.."
cd /tmp
#tar zxf IBM_CLOUD_PRIVATE_1.2.1_INSTALLER.tar.gz
tar zxf ibm-cloud-private-installer-1.2.0.tar.gz
#mv ibm-cloud-private-1.2.1 /opt/
mv ibm-cloud-private-1.2.0 /opt/
#cd /opt/ibm-cloud-private-1.2.1
cd /opt/ibm-cloud-private-1.2.0
#mv /tmp/IBM_CLOUD_PRIVATE_1.2.1_LNX_DOCKE.tar.gz images/
mv /tmp/ibm-cloud-private-x86_64-1.2.0.tar.gz images/

#Prepare hosts and key
cp /tmp/icphosts /opt/ibm-cloud-private-1.2.0/hosts
cp /tmp/icpsshkey /opt/ibm-cloud-private-1.2.0/ssh_key

echo "ansible_user: \"$nodeuser\"" >> /opt/ibm-cloud-private-1.2.0/config.yaml
echo "ansible_become: \"true\"" >> /opt/ibm-cloud-private-1.2.0/config.yaml
echo "default_admin_user: \"$icpuser\"" >> /opt/ibm-cloud-private-1.2.0/config.yaml
echo "default_admin_password: \"$icppassword\"" >> /opt/ibm-cloud-private-1.2.0/config.yaml 

#Run the installer
echo "Running ICp installer.."
tar xf images/ibm-cloud-private-x86_64-1.2.0.tar.gz -C images
#tar xf images/IBM_CLOUD_PRIVATE_1.2.1_LNX_DOCKE.tar.gz -C images
#docker load -i images/ibm-cloud-private-x86_64-1.2.1.tar
#sudo docker load -i images/ibm-cloud-private-x86_64-1.2.0.tar
docker load -i images/ibm-cloud-private-x86_64-1.2.0.tar
#timeout 2000 sudo docker run -e LICENSE=accept --net=host --rm -t -v "$(pwd)":/installer/cluster ibmcom/cfc-installer:1.2.0-ee install 
timeout 2000 docker run -e LICENSE=accept --net=host --rm -t -v "$(pwd)":/installer/cluster ibmcom/cfc-installer:1.2.0-ee install 

echo "Installation Complete"
exit 0
